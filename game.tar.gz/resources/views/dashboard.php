<div id="dashboard-content" class="mdl-grid">
    <a id="new-game-button">New Game</a>
</div>